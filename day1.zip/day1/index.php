
<?php
//code
$x = 25;
$y = "navu";
$z = 30.9;
$n = $x+$z;
//output 
echo "Hello world!!!<br>";
echo $n;
echo $y;
echo "<h2 style='color:purple'>$y<br></h2>";
echo "hello"."navu<br>";
$abc = 27;
if($abc>29){
	echo "Hello<br>";
}
else if($abc>25){
	echo"apple<br>";
}
else {
	echo " goodbye<br>";
}

//loop statement
//for loop:loop that repaets  a fixed number of times
//- you tell the loop that how many times u want loop
//-loop that repeats until a condition is met; 
//-doesn't stop until a condition is met

//
for($i=0; $i<5; $i++){
	echo "hello<br>";
}

//while loop
$b =5;
while($b<8){
	echo "bye<br>";
	$b =$b +1;
}

//function

function sayHello(){
	echo "ABACAXI <br>";
	echo "ANANAS <br>";
}


function fruit($language){
	if($language == "punjabi"){
		echo "ANANAS";
	}
	else if($language == "malayalam"){
		echo "KAITHACHAKA";
	}
	else if($language =="br"){
		echo "ABACAXI";
	}
	else if($language =="viet"){
		echo"DUA";
	}
}

//using a function
sayHello();
$w = "punjabi";
fruit($w);


//Array
//create an array
$animals = [];
$animals = array();

//add thing to the array
$animals[0] = "dog";
$animals[1] ="cat";

//another thing to the array

//for($j = 5;$j<10;$j++)
//{
	//array_push($animals,"fox");
//}

//length of an array
echo"The length of array is:".count($animals);
for($j = 0;$j<count($animals);$j++){
	echo "Hello:".$animals[$j]."<br>";
}

print_r($animals);

//associative array

$easy = array(
"en" => "easy",
"fr" => "facile",
"vt" => "de",
"my" => "elupam",
"gu" => "saral",
"pu" => "sokha"
);
//print everything in the dictionary
print_r($easy);


//single item in trhe dictionary
echo $easy["pu"]."<br>";

//looping through an associate array
foreach($easy as $k => $g){
	echo "Key is: ". $k."<br>";
	echo"Value is: ".$g."<br>";
	echo "----"."<br>";
}

?>