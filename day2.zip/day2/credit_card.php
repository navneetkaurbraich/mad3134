
<p> check credit card! </p>

<?php

	// check if cc is 16 digits long
	$cc = "4288631468815465";

	echo "Your credit card: " . $cc . "<br>";
	
	// if 16 digits, awesome
	if (strlen($cc) == 16) {
		
		// 0. reverse the CC number so all the 
		//   positions match the algorithm
		$reversed = strrev($cc);
		
		// 1. loop through the numbers in the cc
		$total = 0;
		
		for ($i=0; $i< 16; $i++) {
			// @debug: print out each character

			if ($i % 2 == 1) {
				// do multiply + convert
				$num = $reversed[$i] * 2;
				if ($num > 9) {
					//conversion
					$num = $num - 9;
				}
			}
			else {
				//do nothing
				$num = $reversed[$i];
			}
			
			
			// 3. add to the total!
			$total = $total + $num;
		
		} // end for loop
					
		// 4. after looping, do total % 10
		if ($total % 10 == 0) {
			echo "VALID CREDIT CARD! <br>";
		}
		else {
			echo "INVALID!!!! SADNESS! <br>";
		}
	}
	else {
		// sadness!
		echo "your credit card is not 16 digits! <br>";
	}
	
	

	



?>
