 <h1>Hello</h1>
 <h2>This is the next page</h2>
 
 <?php
 //build simple program to check if the person came to this page using a GET and POST request
 //echo for printing normal output
 
 //for arrays
 //print_r($_SERVER);
/* 
 if($_SERVER["REQUEST_METHOD"]=="POST") {
	 //post
	 echo "You came with a post";
 }
 else if ($_SERVER["REQUEST_METHOD"]=="GET"){
	 //get
	 echo "You came with a get";
 }
 */
 echo"<br>What is in the GET?<br>";
print_r( $_GET);

 echo"<br>What is in the POST?<br>";
 print_r($_POST);
 
 echo"The student is: ".$GET["studentName"]."<br>";
 
 echo"The student id is: ".$GET["id"]."<br>";
 ?>
 