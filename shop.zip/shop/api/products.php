<?php
echo "hello";

//1. connect to dba_close
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpassword = "";
	$dbname = "store";

	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

	$query = "SELECT * from products";

	
//2.grab all the locations
	$results = mysqli_query($conn, $query);
	
	$stores=array();
	while($item = mysqli_fetch_assoc($results)){
		array_push($stores,$item);
	}
//3.return all the locations
//tell the browser we're sending json
header("Content-Type:application/json");

//convert our array into a json dictionary
$json = json_encode($stores);

//deal with any kind of error during the conversion
	if($json==false){
		$errorMessage = array("error"=>json_last_error_msg());
		$json= json_encode($json);
		http_response_code(500);
	}

////send the json dictionary to the browser
echo $json;
?>